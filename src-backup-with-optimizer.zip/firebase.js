import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: 'AIzaSyC0co2hBRgGRhyveQRcpoUiSOIFft9MqsA',
  authDomain: 'financial-planner-app-7b255.firebaseapp.com',
  projectId: 'financial-planner-app-7b255',
  storageBucket: 'financial-planner-app-7b255.appspot.com',
  messagingSenderId: '889385402973',
  appId: 'YOUR_APP_ID' //  Optional, but nice to keep
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
