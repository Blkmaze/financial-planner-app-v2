import React, { useState } from 'react';
import Papa from 'papaparse';

export default function FinancialPlanner() {
  const [incomeAmount, setIncomeAmount] = useState('');
  const [expenseAmount, setExpenseAmount] = useState('');
  const [expenseCategory, setExpenseCategory] = useState('Groceries');
  const [history, setHistory] = useState([]);

  const total = history.reduce((sum, item) => {
    return item.type === 'income' ? sum + item.amount : sum - item.amount;
  }, 0);

  const addEntry = (type) => {
    const value = type === 'income' ? parseFloat(incomeAmount) : parseFloat(expenseAmount);
    if (!value || value <= 0) return;

    const entry = {
      id: Date.now(),
      type,
      amount: value,
      category: type === 'expense' ? expenseCategory : 'Income'
    };

    setHistory([entry, ...history]);
    if (type === 'income') {
      setIncomeAmount('');
    } else {
      setExpenseAmount('');
      setExpenseCategory('Groceries');
    }
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const parsedData = results.data;

        const entries = parsedData.map((row) => {
          const amount = parseFloat(row.Amount || row.amount || row['Transaction Amount'] || 0);
          const type = amount < 0 ? 'expense' : 'income';
          return {
            id: Date.now() + Math.random(),
            type,
            amount: Math.abs(amount),
            category: row.Category || row.Description || 'Imported'
          };
        });

        setHistory((prev) => [...entries, ...prev]);
      }
    });
  };

  return (
    <div style={{ marginTop: 40 }}>
      <h2> Budget Tracker</h2>

      <div style={{ marginBottom: 20 }}>
        <input type='file' accept='.csv' onChange={handleFileUpload} />
      </div>

      <div style={{ marginBottom: 10 }}>
        <input
          type='number'
          placeholder='Income Amount'
          value={incomeAmount}
          onChange={(e) => setIncomeAmount(e.target.value)}
        />
        <button onClick={() => addEntry('income')}>Add Income</button>
      </div>

      <div style={{ marginBottom: 10 }}>
        <select
          value={expenseCategory}
          onChange={(e) => setExpenseCategory(e.target.value)}
          style={{ marginRight: 10 }}
        >
          <option>Groceries</option>
          <option>Rent</option>
          <option>Utilities</option>
          <option>Transportation</option>
          <option>Healthcare</option>
          <option>Entertainment</option>
          <option>Automobiles</option>`n          <option>Other</option>
        </select>
        <input
          type='number'
          placeholder='Expense Amount'
          value={expenseAmount}
          onChange={(e) => setExpenseAmount(e.target.value)}
        />
        <button onClick={() => addEntry('expense')}>Add Expense</button>
      </div>

      <h3>Total Balance: </h3>
      <ul>
        {history.map((entry) => (
          <li key={entry.id}>
            {entry.type === 'income' ? '' : ''}   {entry.category}
          </li>
        ))}
      </ul>
    </div>
  );
}
