import React, { useEffect, useState } from 'react';
import { auth } from './firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import Login from './Login';

function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsub();
  }, []);

  const today = new Date().toLocaleDateString(undefined, {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  if (!user) return <Login onLogin={() => {}} />;

  return (
    <div style={{ padding: 40, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
      <div>
        <h1> Welcome, {user.email}</h1>
        <button onClick={() => signOut(auth)}>Logout</button>
        <p>This is your financial planning dashboard.</p>
      </div>
      <div style={{ textAlign: 'right' }}>
        <h3> Today</h3>
        <p>{today}</p>
      </div>
    </div>
  );
}

export default App;
